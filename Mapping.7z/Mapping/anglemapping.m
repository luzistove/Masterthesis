%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This file executes the joint angle mapping from recorded kinect data to the multibody system in 
% simulation. The method in based on this paper "Real-time tele-operation and tele-walking of 
% humanoid Robot Nao using Kinect Depth Camera". Joint angles are calculated using direction 
% vectors in space with [x y z] coordinates. 
%
%                                Recorded data in such form:
% [spinemid spinebase hipleft hipright kneeleft kneeright ankleleft ankleright footleft footright]'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
% load('newdata')
xRecord = inpaintn(xRecord);
yRecord = inpaintn(yRecord);
zRecord = inpaintn(zRecord);


spineMid2BaseX = xRecord(2,:)-xRecord(1,:);
spineMid2BaseY = yRecord(2,:)-yRecord(1,:);
spineMid2BaseZ = zRecord(2,:)-zRecord(1,:);


hip2KneeLX = xRecord(5,:)-xRecord(3,:);
hip2KneeLY = yRecord(5,:)-yRecord(3,:);
hip2KneeLZ = zRecord(5,:)-zRecord(3,:);


hip2KneeRX = xRecord(6,:)-xRecord(4,:);
hip2KneeRY = yRecord(6,:)-yRecord(4,:);
hip2KneeRZ = zRecord(6,:)-zRecord(4,:);


knee2AnkleLX = xRecord(7,:)-xRecord(5,:);
knee2AnkleLY = yRecord(7,:)-yRecord(5,:);
knee2AnkleLZ = zRecord(7,:)-zRecord(5,:);


knee2AnkleRX = xRecord(8,:)-xRecord(6,:);
knee2AnkleRY = yRecord(8,:)-yRecord(6,:);
knee2AnkleRZ = zRecord(8,:)-zRecord(6,:);


ankle2FootLX = xRecord(9,:)-xRecord(7,:);
ankle2FootLY = yRecord(9,:)-yRecord(7,:);
ankle2FootLZ = zRecord(9,:)-zRecord(7,:);


ankle2FootRX = xRecord(10,:)-xRecord(8,:);
ankle2FootRY = yRecord(10,:)-yRecord(8,:);
ankle2FootRZ = zRecord(10,:)-zRecord(8,:);
%%
% Pitch angle
spineMid2Base = [spineMid2BaseZ;zeros(1,length(spineMid2BaseX));spineMid2BaseY];
hip2KneeL = [hip2KneeLZ;zeros(1,length(hip2KneeLX));hip2KneeLY];
hip2KneeR = [hip2KneeRZ;zeros(1,length(hip2KneeRX));hip2KneeRY];
knee2AnkleL = [knee2AnkleLZ;zeros(1,length(knee2AnkleLX));knee2AnkleLY];
knee2AnkleR = [knee2AnkleRZ;zeros(1,length(knee2AnkleRX));knee2AnkleRY];
ankle2FootL = [ankle2FootLZ;zeros(1,length(ankle2FootLX));ankle2FootLY];
ankle2FootR = [ankle2FootRZ;zeros(1,length(ankle2FootRX));ankle2FootRY];

for j = 1:length(xRecord)
    hipPitchL(:,j) = acos(dot(spineMid2Base(:,j),hip2KneeL(:,j))/(norm(spineMid2Base(:,j))*...
        norm(hip2KneeL(:,j))));
    hipPitchR(:,j) = acos(dot(spineMid2Base(:,j),hip2KneeR(:,j))/(norm(spineMid2Base(:,j))*...
        norm(hip2KneeR(:,j))));
    kneeBendL(:,j) = acos(dot(hip2KneeL(:,j),knee2AnkleL(:,j))/(norm(hip2KneeL(:,j))*...
        norm(knee2AnkleL(:,j))));
    kneeBendR(:,j) = acos(dot(hip2KneeR(:,j),knee2AnkleR(:,j))/(norm(hip2KneeR(:,j))*...
        norm(knee2AnkleR(:,j))));
    
    if (spineMid2Base(1,j)-hip2KneeL(1,j)) > 0
        hipPitchL(:,j) = -hipPitchL(:,j);
    else
        hipPitchL(:,j) = hipPitchL(:,j);    
    end

    if (spineMid2Base(1,j)-hip2KneeR(1,j)) > 0
        hipPitchR(:,j) = -hipPitchR(:,j);
    else
        hipPitchR(:,j) = hipPitchR(:,j);
    end
    
    anklePitchL(:,j) = -hipPitchL(:,j)-kneeBendL(:,j);
    anklePitchR(:,j) = -hipPitchR(:,j)-kneeBendR(:,j);

end
% t = linspace(0,4,length(xRecord));

%% Roll angle
spineMid2Base = [zeros(1,length(spineMid2BaseZ));spineMid2BaseX;spineMid2BaseY];
hip2KneeL = [zeros(1,length(hip2KneeLZ));hip2KneeLX;hip2KneeLY];
hip2KneeR = [zeros(1,length(hip2KneeRZ));hip2KneeRX;hip2KneeRY];
knee2AnkleL = [zeros(1,length(knee2AnkleLZ));knee2AnkleLX;knee2AnkleLY];
knee2AnkleR = [zeros(1,length(knee2AnkleRZ));knee2AnkleRX;knee2AnkleRY];
ankle2FootL = [zeros(1,length(ankle2FootLZ));ankle2FootLX;ankle2FootLY];
ankle2FootR = [zeros(1,length(ankle2FootRZ));ankle2FootRX;ankle2FootRY];


for j = 1:length(xRecord)
    hipRollL(:,j) = acos(dot(spineMid2Base(:,j),hip2KneeL(:,j))/(norm(spineMid2Base(:,j))*...
        norm(hip2KneeL(:,j))));
    hipRollR(:,j) = acos(dot(spineMid2Base(:,j),hip2KneeR(:,j))/(norm(spineMid2Base(:,j))*...
        norm(hip2KneeR(:,j))));

    
    if (spineMid2Base(2,j)-hip2KneeL(2,j)) > 0
        hipRollL(:,j) = -hipRollL(:,j);
    else
        hipRollL(:,j) = hipRollL(:,j);    
    end

    if (spineMid2Base(2,j)-hip2KneeR(2,j)) > 0
        hipRollR(:,j) = -hipRollR(:,j);
    else
        hipRollR(:,j) = hipRollR(:,j);
    end
    
    ankleRollL(:,j) = -hipRollL(:,j);
    ankleRollR(:,j) = -hipRollR(:,j);

end
% t = linspace(0,4,length(xRecord));
%%
% Angles already calculated and saved
load('straightWalk5.mat')
% load('kick5.mat')
% load('sideWalk5.mat')
% load('halfStep5.mat')
temp = straightWalk5;
% temp = kick5;
% temp = sideWalk5;
% temp = halfStep5;
dt = 0.01;
t = 0:dt:0.1*size(temp,2)-0.1;
temp1 = pchip(0:0.1:0.1*size(temp,2)-0.1,temp,t);

% straight walking

% temp1(:,551:end) = [];
% temp1(:,1:344) = [];
%kick
% temp1(:,690:end) = [];
% temp1(:,1:410) = [];
% side walking
% temp1(:,630:end) = [];
% temp1(:,1:415) = [];
% first half step
% temp1(:,346:end) = [];
% temp1(:,1:140) = [];
% final half step
% temp1(:,1100:end) = [];
% temp1(:,1:870) = [];

% temp1(:,446:end) = [];
% temp1(:,1:339) = [];
hipPitchL = mean([temp1(1,:);temp1(11,:);temp1(21,:);temp1(31,:);temp1(41,:)]);
hipPitchR = mean([temp1(2,:);temp1(12,:);temp1(22,:);temp1(32,:);temp1(42,:)]);
kneeBendL = -mean([temp1(3,:);temp1(13,:);temp1(23,:);temp1(33,:);temp1(43,:)]);
kneeBendR = -mean([temp1(4,:);temp1(14,:);temp1(24,:);temp1(34,:);temp1(44,:)]);
anklePitchL = mean([temp1(5,:);temp1(15,:);temp1(25,:);temp1(35,:);temp1(45,:)]);
anklePitchR = mean([temp1(6,:);temp1(16,:);temp1(26,:);temp1(36,:);temp1(46,:)]);
hipRollL = mean([temp1(7,:);temp1(17,:);temp1(27,:);temp1(37,:);temp1(47,:)]);
hipRollR = mean([temp1(8,:);temp1(18,:);temp1(28,:);temp1(38,:);temp1(48,:)]);
ankleRollL = mean([temp1(9,:);temp1(19,:);temp1(29,:);temp1(39,:);temp1(49,:)]);
ankleRollR = mean([temp1(10,:);temp1(20,:);temp1(30,:);temp1(40,:);temp1(50,:)]);


t = 0:dt:0.01*size(temp1,2)-0.01;


% run('Nao_parameter')
% sim('motionmappingtest.slx')
%% std plot
fs = 15;
limitX = max(t);
figure(1)
subplot(5,2,1)
H(1) = shadedErrorBar(t,mean([temp1(1,:);temp1(11,:);temp1(21,:);temp1(31,:);temp1(41,:)]),...
    std([temp1(1,:);temp1(11,:);temp1(21,:);temp1(31,:);temp1(41,:)]),'lineprops','r');
hold on
% plot([3.4 3.4], [-0.5 0.5],'k','LineWidth',2);
% hold on
% plot([4.45 4.45], [-0.5 0.5],'k','LineWidth',2);
% P1 = plot(t,anglesIm(1,:),'b--','LineWidth',2);
grid on
% % xlabel('time [s]')
ylabel('angle [rad]')
title('Left hip pitch angle')
xlim([0,limitX])
set(gca,'fontsize',fs)
subplot(5,2,2)
H(2) = shadedErrorBar(t,mean([temp1(2,:);temp1(12,:);temp1(22,:);temp1(32,:);temp1(42,:)]),...
    std([temp1(2,:);temp1(12,:);temp1(22,:);temp1(32,:);temp1(42,:)]),'lineprops','r');
y2 = ylim;
% hold on
% plot([3.4 3.4],[y2(1) y2(2)],'k','LineWidth',2);
% hold on
% plot([4.45 4.45],[y2(1) y2(2)],'k','LineWidth',2);
% plot(t,anglesIm(2,:),'b--','LineWidth',2)
grid on
% % xlabel('time [s]')
ylabel('angle [rad]')
title('Right hip pitch angle')
xlim([0,limitX])
% ylim([-0.8 0.8])
set(gca,'fontsize',fs)
subplot(5,2,3)
H(3) = shadedErrorBar(t,-mean([temp1(3,:);temp1(13,:);temp1(23,:);temp1(33,:);temp1(43,:)]),...
    -std([temp1(3,:);temp1(13,:);temp1(23,:);temp1(33,:);temp1(43,:)]),'lineprops','r');
y3 = ylim;
hold on
% plot([3.4 3.4],[y3(1) y3(2)],'k','LineWidth',2);
% hold on
% plot([4.45 4.45],[y3(1) y3(2)],'k','LineWidth',2);
% plot(t,anglesIm(3,:),'b--','LineWidth',2)
grid on
% xlabel('time [s]')
ylabel('angle [rad]')
title('Left knee bending angle')
xlim([0,limitX])
set(gca,'fontsize',fs)
subplot(5,2,4)
H(4) = shadedErrorBar(t,-mean([temp1(4,:);temp1(14,:);temp1(24,:);temp1(34,:);temp1(44,:)]),...
    -std([temp1(4,:);temp1(14,:);temp1(24,:);temp1(34,:);temp1(44,:)]),'lineprops','r');
y4 =ylim;
hold on
% plot([3.4 3.4],[y4(1) y4(2)],'k','LineWidth',2);
% hold on
% plot([4.45 4.45],[y4(1) y4(2)],'k','LineWidth',2);
% plot(t,anglesIm(4,:),'b--','LineWidth',2)
grid on
% xlabel('time [s]')
ylabel('angle [rad]')
title('Right knee bending angle')
xlim([0,limitX])
set(gca,'fontsize',fs)
subplot(5,2,5)
H(5) = shadedErrorBar(t,mean([temp1(5,:);temp1(15,:);temp1(25,:);temp1(35,:);temp1(45,:)]),...
    std([temp1(5,:);temp1(15,:);temp1(25,:);temp1(35,:);temp1(45,:)]),'lineprops','r');
y5 = ylim;
hold on
% plot([3.4 3.4],[y5(1) y5(2)],'k','LineWidth',2);
% hold on
% plot([4.45 4.45],[y5(1) y5(2)],'k','LineWidth',2);
% plot(t,anglesIm(5,:),'b--','LineWidth',2)
grid on
% xlabel('time [s]')
ylabel('angle [rad]')
title('Left ankle pitch angle')
xlim([0,limitX])
% ylim([-0.8,0.5])
set(gca,'fontsize',fs)
subplot(5,2,6)
H(6) = shadedErrorBar(t,mean([temp1(6,:);temp1(16,:);temp1(26,:);temp1(36,:);temp1(46,:)]),...
    std([temp1(6,:);temp1(16,:);temp1(26,:);temp1(36,:);temp1(46,:)]),'lineprops','r');
y6 = ylim;
hold on
% plot([3.4 3.4],[y6(1) y6(2)],'k','LineWidth',2);
% hold on
% plot([4.45 4.45],[y6(1) y6(2)],'k','LineWidth',2);
% plot(t,anglesIm(6,:),'b--','LineWidth',2)
grid on
% xlabel('time [s]')
ylabel('angle [rad]')
title('Right ankle pitch angle')
xlim([0,limitX])
set(gca,'fontsize',fs)
subplot(5,2,7)
H(7) = shadedErrorBar(t,mean([temp1(7,:);temp1(17,:);temp1(27,:);temp1(37,:);temp1(47,:)]),...
    std([temp1(7,:);temp1(17,:);temp1(27,:);temp1(37,:);temp1(47,:)]),'lineprops','r');
y7 = ylim;
hold on
% plot([3.4 3.4],[y7(1) y7(2)],'k','LineWidth',2);
% hold on
% plot([4.45 4.45],[y7(1) y7(2)],'k','LineWidth',2);
% plot(t,anglesIm(7,:),'b--','LineWidth',2)
grid on
% xlabel('time [s]')
ylabel('angle [rad]')
title('Left hip roll angle')
xlim([0,limitX])
set(gca,'fontsize',fs)
subplot(5,2,8)
H(8) = shadedErrorBar(t,mean([temp1(8,:);temp1(18,:);temp1(28,:);temp1(38,:);temp1(48,:)]),...
    std([temp1(8,:);temp1(18,:);temp1(28,:);temp1(38,:);temp1(48,:)]),'lineprops','r');
y8 = ylim;
hold on
% plot([3.4 3.4],[y8(1) y8(2)],'k','LineWidth',2);
% hold on
% plot([4.45 4.45],[y8(1) y8(2)],'k','LineWidth',2);
% plot(t,anglesIm(8,:),'b--','LineWidth',2)
grid on
% xlabel('time [s]')
ylabel('angle [rad]')
title('Right hip roll angle')
xlim([0,limitX])
set(gca,'fontsize',fs)
subplot(5,2,9)
H(9) = shadedErrorBar(t,mean([temp1(9,:);temp1(19,:);temp1(29,:);temp1(39,:);temp1(49,:)]),...
    std([temp1(9,:);temp1(19,:);temp1(29,:);temp1(39,:);temp1(49,:)]),'lineprops','r');
y9 = ylim;
% hold on
% plot([3.4 3.4],[y9(1) y9(2)],'k','LineWidth',2);
% hold on
% plot([4.45 4.45],[y9(1) y9(2)],'k','LineWidth',2);
% plot(t,anglesIm(9,:),'b--','LineWidth',2)
grid on
xlabel('time [s]')
ylabel('angle [rad]')
title('Left ankle roll angle')
xlim([0,limitX])
set(gca,'fontsize',fs)
subplot(5,2,10)
H(10) = shadedErrorBar(t,mean([temp1(10,:);temp1(20,:);temp1(30,:);temp1(40,:);temp1(50,:)]),...
    std([temp1(10,:);temp1(20,:);...
    temp1(30,:);temp1(40,:);temp1(50,:)]),'lineprops','r');
y10 = ylim;
hold on
% plot([3.4 3.4],[y10(1) y10(2)],'k','LineWidth',2);
% hold on
% plot([4.45 4.45],[y10(1) y10(2)],'k','LineWidth',2);
% plot(t,anglesIm(10,:),'b--','LineWidth',2)
grid on
xlabel('time [s]')
ylabel('angle [rad]')
title('Right ankle roll angle')
xlim([0,limitX])
set(gca,'fontsize',fs)
H(1).mainLine.LineWidth = 2;
H(2).mainLine.LineWidth = 2;
H(3).mainLine.LineWidth = 2;
H(4).mainLine.LineWidth = 2;
H(5).mainLine.LineWidth = 2;
H(6).mainLine.LineWidth = 2;
H(7).mainLine.LineWidth = 2;
H(8).mainLine.LineWidth = 2;
H(9).mainLine.LineWidth = 2;
H(10).mainLine.LineWidth = 2;


% l1 = legend([H(1).mainLine,P1],'Trajectory template','Trajectory by imitation','Location',[0.5 0.95 0.05 0.05],'Orientation','horizontal');
% set(l1,'fontsize',15)