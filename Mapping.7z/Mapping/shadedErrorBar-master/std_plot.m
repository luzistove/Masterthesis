% d = [0.01,0.03,0.05,0.07];
% pid_ov_y = pid_ov_y .* 100;
% pid_ov_y = pid_ov_y .* 100;
% pp_ts_y = pp_ts_y';
% pp_ts_y = pp_ts_y';
% y_mean = zeros(1,5);
% y_mean = zeros(1,5);
% y_std = zeros(1,5);
% y_std = zeros(1,5);
% for i = 0:4
%     y_mean(:,i+1) = mean(kyky_sse(2*i+1,:));
%     y_std(:,i+1) = std(kyky_sse(2*i+1,:));
%     y_mean(:,i+1) = mean(kyky_sse(2*i+2,:));
%     y_std(:,i+1) = std(kyky_sse(2*i+2,:));
% end



figure(1)

% set(gca,'yTick',1:5);
% set(gca,'yTickLabel',{0.1,1,10,100,1000});
% % ayes([0.09 1001 0 25]);
% e1 = errorbar(y_mean,y_std,'Capsize',18);
% e1.Color = 'red';
% e1.Marker = 's';
% hold on
% plot(y_mean,'Color','r','Linewidth',2)
% hold on
% e2 = errorbar(y_mean,y_std,'Capsize',18);
% e2.Color = 'blue';
% e2.Marker = 'o';
% hold on
% plot(y_mean,'Color','b','Linewidth',2


ref_x = 100.*ones(301,10);
ref_y = 80.*ones(301,10);

t=0:0.1:30;

H(1) = shadedErrorBar(t,mean(ref_x'),std(ref_x'),'lineprops','-k');
hold on
H(2) = shadedErrorBar(t,mean(ref_y'),std(ref_y'),'lineprops','-k');
hold on
H(3) = shadedErrorBar(t,mean(uni_new_16_x'),std(uni_new_16_x'),'lineprops','r');
hold on
H(4) = shadedErrorBar(t,mean(uni_new_16_y'),std(uni_new_16_y'),'lineprops','g');
hold on
% H(5) = shadedErrorBar(t,mean(uni_new_17_y'),std(uni_new_17_y'),'lineprops','g');
% hold on
% H(6) = shadedErrorBar(t,mean(pos_y'),std(pos_y'),'lineprops','m');
% hold on

% H(3) = shadedErrorBar(t,mean(ref_y'),std(ref_y'),'lineprops','k');
% hold on
% H(4) = shadedErrorBar(t,mean(ref_y'),std(ref_y'),'lineprops','k');
% hold on
% p1 = plot(t,pos(:,4)');
% hold on
% p2 = plot(t,pos(:,5)');
% 
% H(3) = shadedErrorBar(t,mean(mod_y'),std(mod_y'),'lineprops','b');
% hold on
% H(4) = shadedErrorBar(t,mean(mod_y'),std(mod_y'),'lineprops','m');
% hold on
H(1).mainLine.LineWidth = 0.5;
% H(2).mainLine.LineWidth = 0.5;


H(3).mainLine.LineWidth = 1.5;
H(4).mainLine.LineWidth = 1.5;
H(5).mainLine.LineWidth = 1.5;
% H(6).mainLine.LineWidth = 1.5;

% p1.LineWidth = 2;
% p2.LineWidth = 2;
legend([H(1).mainLine,H(2).mainLine...
    H(3).mainLine,H(4).mainLine,...
    H(3).patch,H(4).patch],'Reference','Reference','Mean response: x direction',...
    'Mean response: y direction',...
    'std: x direction','std: y direction');
axis([0,30,-5,120])
xlabel('time(s)');
ylabel('Position(cm)');
% hold on
% fill(y_mean-y_std,y_mean+y_std,[0 1.5 0])
grid on
