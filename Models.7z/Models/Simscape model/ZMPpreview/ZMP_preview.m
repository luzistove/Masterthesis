%%
% first define ZMP equation
g = 9.81;
A = [0 1 0;0 0 1;0 0 0];
B = [0 0 1]';
C = [1 0 -torso_height/g];
D = 0;
Ts = 0.01;
t = 0:0.01:2;
sys_ZMP = ss(A,B,C,D);
sys_ZMPd = c2d(sys_ZMP,0.01,'zoh');
[Ad,Bd,Cd,Dd] = dssdata(sys_ZMPd);
% figure(1)
% step(sys_ZMP)
% figure(2)
% step(sys_ZMPd)
%%
% define the ZMP trajectories in x and y direction
% time = t(:,end);
% zmp = 0.05;
% stepStraight = 0.03;
% stepDuration = 0.2;
% tt = 0:0.01:stepDuration;
% tt1 = stepDuration*[0 0.25 0.5 0.75 1];
% % zmp y
% begY = pchip(tt1,[0 0 0 0 -zmp],tt);
% NY = (time-2*stepDuration)/(2*stepDuration);
% cycleYD = pchip(tt1,[-zmp -zmp -zmp -zmp -zmp],tt);
% cycleYD(:,1) = [];
% cycleYU = pchip(tt1,[zmp zmp zmp zmp zmp],tt);
% cycleYU(:,1) = [];
% cycleY = [cycleYD cycleYU];
% endY = pchip(tt1,[zmp zmp zmp zmp zmp],tt);
% endY(:,1) = [];
% Y = [begY repmat(cycleY,1,NY) endY];
% 
% % zmp x
% NX = time/stepDuration-1;
% zmpXX = zeros(NX+1,length(t));
% for i = 2:NX-1
%     zmpXX(i+2,:) = stepStraight*ones(1,length(t));
%     zmpXX(i+2,1:i*length(tt)-i+1) = zeros(1,i*length(tt)-i+1);
% end
% X = sum(zmpXX);

%%
% define gains
Qe = 1000;
Qx = [0 0 0;0 0 0;0 0 0];%[1 0 0;0 1 0;0 0 1];
R = 1;
B_til = [Cd*Bd;Bd];
F_til = [Cd*Ad;Ad];
I_til = [1 zeros(1,3)]';
A_til = [I_til F_til];

Q_til = [Qe zeros(1,3);zeros(3,1) Qx];
[K_til,L,G] = dare(A_til,B_til,Q_til,R);
A_ctil = A_til-B_til*(R+B_til'*K_til*B_til)'*B_til'*K_til*A_til;
Ge = (R+B_til'*K_til*B_til)^(-1)*B_til'*K_til*I_til;
Gx = (R+B_til'*K_til*B_til)^(-1)*B_til'*K_til*F_til;

%%
% define preview control signal
N = 50;  % preview steps
% up_x = zeros(1,size(X,2));
Y = Y';
Y(1,:) = [];
up_y = zeros(1,size(Y,2));
Gp = zeros(1,N);
X_til = zeros(4,N);
%% 
% zmp in x direction
% for k = 1:length(X)
%     temp1_x = 0;
%     if ((k+N) <= length(X))
%         for l = 1:N
%             if l == 1
%                 X_til(:,1) = -A_ctil'*K_til*I_til;
%                 Gp(l) = -Ge;
%             elseif l >= 2
%                 Gp(l) = (R+B_til'*K_til*B_til)\B_til'*X_til(:,l-1);
%                 X_til(:,l) = A_ctil'*X_til(:,l-1); 
%             end
%             temp1_x = temp1_x + Gp(l)*X(1,k+l);
%         end
%         up_x(k) = temp1_x;
%     else
%         up_x(k) = up_x(k-1);
%     end
% end
% ux = [0:1500;up_x]';
%%
% zmp in y direction
for k = 1:length(Y)
    temp1_y = 0;
    if ((k+N) <= length(Y))
        for l = 1:N
            if l == 1
                X_til(:,1) = -A_ctil'*K_til*I_til;
                Gp(l) = -Ge;
            elseif l >= 2
                Gp(l) = (R+B_til'*K_til*B_til)\B_til'*X_til(:,l-1);
                X_til(:,l) = A_ctil'*X_til(:,l-1); 
            end
            temp1_y = temp1_y + Gp(l)*Y(1,k+l);
        end
        up_y(k) = temp1_y;
    else
        up_y(k) = up_y(k-1);
    end
end
% u = [up_x;up_y];
