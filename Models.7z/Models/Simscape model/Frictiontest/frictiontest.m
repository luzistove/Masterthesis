t = 0:0.01:1;
t1 = 0:0.1:1;
hip = pchip(t1,[0 0.05 0.08 0.1 0.15 0 -0.5 -0.3 -0.15 -0.1 0],t);
knee = pchip(t1,[0 0 0 0 -0.4 -0.8 -0.4 0 0 0 0],t);
ankle = hip-knee;
plot(t,hip,'r','LineWidth',2)
hold on
plot(t,knee,'b','LineWidth',2)
hold on
plot(t,ankle,'g','LineWidth',2)
grid on
xlabel('time [s]');
ylabel('angle [rad]')
l1 = legend('Hip pitch motion','Knee bending motion','Ankle pitch motion');
set(l1,'fontsize',20)
set(gca,'fontsize',20)
run('Nao_parameter')
%%
kinetic_friction = 1000;
static_friction = 1000;